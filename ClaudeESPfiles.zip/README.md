# 🎯 ESP32-CAM Laser Target Tracker

**Ein vollautomatisches Laser-Treffererkennung-System mit ESP32-CAM und WebUI**

![Version](https://img.shields.io/badge/version-1.0-blue)
![Platform](https://img.shields.io/badge/platform-ESP32--CAM-green)
![License](https://img.shields.io/badge/license-MIT-orange)

---

## 🌟 Überblick

Dieses Projekt verwandelt deinen ESP32-CAM in ein intelligentes Laser-Zielscheiben-Tracking-System. Die Kamera erkennt automatisch Laserimpulse auf einer Zielscheibe, berechnet die Punktzahl und zeigt alles in einer schicken WebUI an.

### ✨ Hauptfeatures

- 🎯 **Automatische Lasererkennung** mit Echtzeit-Bildverarbeitung
- 📐 **4-Punkte-Kalibrierung** für präzise Treffererkennung
- 🌐 **Moderne WebUI** mit Live-Updates
- 💾 **Persistente Speicherung** der Kalibrierung im EEPROM
- 📊 **Detaillierte Statistiken** (Gesamtpunktzahl, Ring-Treffer, Durchschnitt)
- ⚙️ **Einstellbare Parameter** (Helligkeit, Kontrast, Schwellwert)
- 🎨 **Visuelle Darstellung** aller Einschusslöcher

---

## 🚀 Schnellstart

### 1. Hardware benötigt
- ESP32-CAM Modul (AI-Thinker)
- FTDI USB-zu-Serial Programmer
- Laser Pointer
- Zielscheibe (siehe `print_target.png`)

### 2. Installation
```bash
# Arduino IDE: Öffne ESP32_LaserTarget_Tracker.ino
# ODER
# VS Code: Öffne VSCode-Ordner mit PlatformIO
```

### 3. Konfiguration
Ändere in der `.ino` oder `main.cpp`:
```cpp
const char* ssid = "DEIN_WIFI";
const char* password = "DEIN_PASSWORT";
```

### 4. Upload & Start
- Verbinde ESP32-CAM via FTDI
- GPIO0 mit GND verbinden
- Upload drücken
- GPIO0 trennen, Reset drücken

### 5. WebUI öffnen
```
http://IP_ADRESSE (siehe Serial Monitor)
```

**→ Detaillierte Anleitung:** [QUICKSTART.md](QUICKSTART.md)

---

## 📁 Projektstruktur

```
ESP32_LaserTarget_Tracker/
│
├── 📄 README.md                    ← Du bist hier
├── 📄 QUICKSTART.md                ← Schnellstart-Guide
├── 📄 HARDWARE_SETUP.md            ← Hardware & Verkabelung
│
├── 📁 Arduino/                     ← Arduino IDE Projekt
│   └── ESP32_LaserTarget_Tracker.ino
│
├── 📁 VSCode/                      ← VS Code / PlatformIO Projekt
│   ├── platformio.ini
│   └── src/
│       └── main.cpp
│
├── 📁 docs/                        ← Vollständige Dokumentation
│   └── README.md
│
├── 📁 demo/                        ← Interaktive WebUI Demo
│   └── LaserTargetDemo.jsx         ← React Demo Component
│
└── 📄 print_target.png             ← Zielscheibe zum Ausdrucken (A4)
```

---

## 🎮 Verwendung

### Workflow:

1. **Kalibrierung** (einmalig) → Klicke auf "📐 Kalibrierung"
2. **4 Punkte klicken** → Markiere die Ecken der Zielscheibe (1→2→3→4)
3. **System startet automatisch** → Sofort einsatzbereit!
4. **Schießen!** → Laser auf Zielscheibe richten
5. **Ergebnisse sehen** → WebUI zeigt Treffer, Punkte und Statistiken

**Nach dem ersten Kalibrieren:** System startet bei jedem Neustart automatisch.

### WebUI Features:

| Bereich | Funktion |
|---------|----------|
| **Sidebar** | Gesamtpunktzahl, Treffer pro Ring, Letzte Schüsse, Durchschnitt |
| **Zielscheibe** | Visuelle Darstellung aller Einschusslöcher |
| **Controls** | Start, Stop, Reset, Kalibrierung |
| **Einstellungen** | Helligkeit, Kontrast, Sättigung, Laser-Schwellwert |

---

## 🛠️ Technische Details

### Hardware
- **Mikrocontroller:** ESP32 (Dual-Core, 240MHz)
- **Kamera:** OV2640 (2MP, 320x240 bei ~30 FPS)
- **WiFi:** 2.4GHz 802.11 b/g/n
- **Speicher:** 4MB Flash, EEPROM für Kalibrierung

### Software
- **Framework:** Arduino / ESP-IDF
- **Bildverarbeitung:** Grayscale, Helligkeits-Schwellwert
- **Webserver:** Asynchroner HTTP Server
- **Frontend:** Vanilla JavaScript (kein Framework nötig)
- **Datenformat:** JSON (ArduinoJson Library)

### Algorithmus

1. **Bilderfassung:** 320x240 Grayscale @ max FPS
2. **Laser-Detektion:** Suche nach hellstem Pixel über Schwellwert
3. **Koordinaten-Transformation:** 4-Punkt-Perspektiv-Korrektur
4. **Punktberechnung:** Distanz vom Zentrum → Ring-Nummer
5. **Delay:** 1 Sekunde zwischen Schüssen (konfigurierbar)

---

## ⚙️ Konfigurationsoptionen

### Im Code änderbar:

```cpp
// WiFi
const char* ssid = "...";
const char* password = "...";

// Bildauflösung (höher = präziser, aber langsamer)
config.frame_size = FRAMESIZE_QVGA; // 320x240

// Delay zwischen Schüssen (in Millisekunden)
const unsigned long SHOT_DELAY = 1000;

// Maximum gespeicherte Schüsse
#define MAX_SHOTS 100
```

### In WebUI änderbar:

- **Helligkeit:** -2 bis +2
- **Kontrast:** -2 bis +2
- **Sättigung:** -2 bis +2
- **Laser-Schwellwert:** 100-255 (Standard: 200)

---

## 🐛 Troubleshooting

| Problem | Lösung |
|---------|--------|
| Upload schlägt fehl | GPIO0 mit GND verbinden, dann Upload |
| Kein WiFi | Nur 2.4GHz unterstützt, SSID/Passwort prüfen |
| Laser nicht erkannt | Schwellwert senken (150-180) |
| Zu viele Fehlalarme | Schwellwert erhöhen (220-240) |
| Brownout-Resets | Stärkeres Netzteil (min. 1A) verwenden |
| Kamera-Fehler | Stromversorgung prüfen, Reset drücken |

**→ Mehr Details:** [docs/README.md](docs/README.md#troubleshooting)

---

## 📖 Dokumentation

- **[QUICKSTART.md](QUICKSTART.md)** - Schnellstart in 5 Schritten
- **[HARDWARE_SETUP.md](HARDWARE_SETUP.md)** - Verkabelung & Hardware-Setup
- **[docs/README.md](docs/README.md)** - Vollständige Dokumentation
- **[demo/](demo/)** - Interaktive WebUI Demo

---

## 🎯 Demo ausprobieren

Eine interaktive Demo der WebUI findest du in `demo/LaserTargetDemo.jsx`. 

Du kannst sie direkt im Browser testen:
1. Öffne die `.jsx` Datei in einem React-fähigen Editor
2. Oder kopiere den Code in einen Online-React-Editor (z.B. CodeSandbox)
3. Klicke auf "Kalibrierung" → 4x auf Ecken klicken → "Start" → Auf Zielscheibe klicken!

---

## 🔜 Zukünftige Features

- [ ] MJPEG Live-Stream der Kamera
- [ ] Mehrere Benutzer/Profile
- [ ] Training-Modi (z.B. "10 Schüsse in 60 Sek")
- [ ] Datenbank-Integration (SQLite)
- [ ] Mobile App (React Native)
- [ ] Ton-Feedback bei Treffern
- [ ] Automatische Laser-Farberkennung
- [ ] Export der Ergebnisse (CSV, PDF)

---

## 📊 API-Dokumentation

### Verfügbare Endpunkte

```
GET  /                              → WebUI
GET  /api/status                    → System-Status & Statistiken
GET  /api/shots                     → Alle Schuss-Daten
GET  /api/reset                     → Treffer zurücksetzen
GET  /api/start                     → System starten
GET  /api/stop                      → System stoppen
GET  /api/calibrate?action=start    → Kalibrierung starten
GET  /api/calibrate?action=point&x=...&y=...  → Kalibrierungspunkt
POST /api/settings                  → Einstellungen speichern (JSON)
```

**Beispiel:**
```bash
curl http://192.168.1.100/api/status
# → {"status":"Aktiv","totalScore":67,"shotCount":10,...}
```

---

## 🏆 Punktesystem

| Ring | Punkte | Farbe | Entfernung vom Zentrum |
|------|--------|-------|------------------------|
| 9 | 9 | Weiß | 0-55 Pixel |
| 8 | 8 | Grau | 56-111 Pixel |
| 7 | 7 | Weiß | 112-166 Pixel |
| 6 | 6 | Schwarz | 167-222 Pixel |
| 5 | 5 | Weiß | 223-277 Pixel |
| 4 | 4 | Grau | 278-333 Pixel |
| 3 | 3 | Weiß | 334-388 Pixel |
| 2 | 2 | Grau | 389-444 Pixel |
| 1 | 1 | Weiß | 445-500 Pixel |
| 0 | 0 | - | >500 Pixel (Fehlschuss) |

---

## 🙏 Danksagungen

Dieses Projekt wurde inspiriert von:
- ESP32-CAM Community
- Laser Range Finder Projekten
- Shooting Sport Tracking Apps

---

## 📜 Lizenz

MIT License - Frei verwendbar für private und kommerzielle Zwecke.

---

## 🤝 Mitwirken

Verbesserungsvorschläge, Bug-Reports und Pull Requests sind willkommen!

1. Fork das Projekt
2. Erstelle einen Feature-Branch (`git checkout -b feature/NeuesFeature`)
3. Commit deine Änderungen (`git commit -m 'Füge neues Feature hinzu'`)
4. Push zum Branch (`git push origin feature/NeuesFeature`)
5. Erstelle einen Pull Request

---

## 📧 Kontakt & Support

Bei Fragen oder Problemen:
1. Siehe [Troubleshooting](docs/README.md#troubleshooting)
2. Prüfe Serial Monitor Output
3. Teste Kalibrierung erneut
4. Öffne ein Issue auf GitHub

---

## 🎯 Screenshots

### WebUI Hauptansicht
- Sidebar mit Statistiken
- Zielscheibe mit Einschusslöchern
- Controls (Start, Stop, Reset, Kalibrierung)
- Kamera-Einstellungen

### Kalibrierung
- 4-Punkt-Kalibrierung im Uhrzeigersinn
- Visuelle Markierung der Kalibrierungspunkte

### Live-Tracking
- Echtzeit-Updates bei jedem Schuss
- Visuelle Darstellung aller Treffer
- Detaillierte Statistiken

---

**Viel Erfolg beim Aufbau und gutes Zielen! 🎯**

---

**Made with ❤️ für alle Laser-Enthusiasten**
