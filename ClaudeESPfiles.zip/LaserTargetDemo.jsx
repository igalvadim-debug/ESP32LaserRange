import React, { useState, useEffect } from 'react';

export default function LaserTargetDemo() {
  const [totalScore, setTotalScore] = useState(0);
  const [shots, setShots] = useState([]);
  const [ringHits, setRingHits] = useState([0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
  const [systemActive, setSystemActive] = useState(false);
  const [isCalibrated, setIsCalibrated] = useState(false);
  const [calibrationMode, setCalibrationMode] = useState(false);
  const [calibrationStep, setCalibrationStep] = useState(0);
  const [settings, setSettings] = useState({
    brightness: 0,
    contrast: 0,
    saturation: 0,
    threshold: 200
  });

  // Demo-Modus: Simuliere zufällige Schüsse
  const simulateShot = () => {
    if (!systemActive || !isCalibrated) return;

    // Zufällige Position mit Normalverteilung um Zentrum
    const angle = Math.random() * Math.PI * 2;
    const distance = Math.abs(Math.random() * 250 + Math.random() * 250); // Normalverteilt
    
    const x = 500 + Math.cos(angle) * distance;
    const y = 500 + Math.sin(angle) * distance;

    const score = calculateScore(x, y);
    
    const newShot = { x, y, score, timestamp: Date.now() };
    setShots(prev => [...prev, newShot]);
    setTotalScore(prev => prev + score);
    
    const newRingHits = [...ringHits];
    newRingHits[score]++;
    setRingHits(newRingHits);
  };

  const calculateScore = (x, y) => {
    const dx = x - 500;
    const dy = y - 500;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const ringWidth = 55.5;

    if (distance < ringWidth * 1) return 9;
    if (distance < ringWidth * 2) return 8;
    if (distance < ringWidth * 3) return 7;
    if (distance < ringWidth * 4) return 6;
    if (distance < ringWidth * 5) return 5;
    if (distance < ringWidth * 6) return 4;
    if (distance < ringWidth * 7) return 3;
    if (distance < ringWidth * 8) return 2;
    if (distance < ringWidth * 9) return 1;
    return 0;
  };

  const handleTargetClick = (e) => {
    if (calibrationMode) {
      // Kalibrierungsmodus: Zeige Punkt an
      const svg = e.currentTarget;
      const rect = svg.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 1000;
      const y = ((e.clientY - rect.top) / rect.height) * 1000;
      
      if (calibrationStep < 4) {
        setCalibrationStep(prev => prev + 1);
        
        if (calibrationStep === 3) {
          setCalibrationMode(false);
          setIsCalibrated(true);
          setCalibrationStep(0);
          alert('Kalibrierung abgeschlossen! Du kannst jetzt mit "Start" beginnen.');
        }
      }
    } else if (systemActive && isCalibrated) {
      // Manueller Schuss durch Klick
      const svg = e.currentTarget;
      const rect = svg.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 1000;
      const y = ((e.clientY - rect.top) / rect.height) * 1000;
      
      const score = calculateScore(x, y);
      const newShot = { x, y, score, timestamp: Date.now() };
      
      setShots(prev => [...prev, newShot]);
      setTotalScore(prev => prev + score);
      
      const newRingHits = [...ringHits];
      newRingHits[score]++;
      setRingHits(newRingHits);
    }
  };

  const startCalibration = () => {
    setCalibrationMode(true);
    setCalibrationStep(0);
    setSystemActive(false);
    alert('Kalibrierung: Klicke nacheinander auf die 4 Eckpunkte der Zielscheibe im Uhrzeigersinn.\n\n1. Oben links\n2. Oben rechts\n3. Unten rechts\n4. Unten links');
  };

  const resetShots = () => {
    if (confirm('Alle Treffer zurücksetzen?')) {
      setShots([]);
      setTotalScore(0);
      setRingHits([0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
    }
  };

  const startSystem = () => {
    if (isCalibrated) {
      setSystemActive(true);
    } else {
      alert('Bitte zuerst kalibrieren!');
    }
  };

  const stopSystem = () => {
    setSystemActive(false);
  };

  const avgScore = shots.length > 0 ? (totalScore / shots.length).toFixed(1) : '0.0';

  const statusText = calibrationMode ? 'Kalibrierung' : (systemActive ? 'Aktiv' : 'Gestoppt');
  const statusClass = calibrationMode ? 'status-calibrating' : (systemActive ? 'status-active' : 'status-inactive');

  return (
    <div style={{
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      minHeight: '100vh',
      padding: '20px'
    }}>
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto',
        background: 'white',
        borderRadius: '20px',
        padding: '30px',
        boxShadow: '0 20px 60px rgba(0,0,0,0.3)'
      }}>
        <h1 style={{
          textAlign: 'center',
          color: '#333',
          marginBottom: '30px',
          fontSize: '2.5em'
        }}>
          🎯 ESP32 Laser Target Tracker - DEMO
        </h1>

        <div style={{
          background: '#fff3cd',
          border: '2px solid #ffc107',
          borderRadius: '10px',
          padding: '15px',
          marginBottom: '20px',
          textAlign: 'center'
        }}>
          <strong>Demo-Modus:</strong> Klicke auf "Kalibrierung" → Klicke 4x auf die Ecken → "Start" → Klicke auf die Zielscheibe zum Schießen!
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: '300px 1fr',
          gap: '30px',
          marginBottom: '30px'
        }}>
          {/* Sidebar */}
          <div style={{
            background: '#f8f9fa',
            padding: '20px',
            borderRadius: '15px'
          }}>
            <div style={{
              background: 'white',
              padding: '15px',
              borderRadius: '10px',
              marginBottom: '15px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
            }}>
              <h3 style={{ color: '#667eea', marginBottom: '10px', fontSize: '1.1em' }}>Status</h3>
              <p>
                <span style={{
                  display: 'inline-block',
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  marginRight: '8px',
                  background: statusClass === 'status-active' ? '#2ecc71' : 
                             statusClass === 'status-calibrating' ? '#f39c12' : '#e74c3c'
                }} />
                {statusText}
              </p>
              {!isCalibrated && <p style={{ color: '#e74c3c', fontSize: '0.9em', marginTop: '5px' }}>⚠️ Nicht kalibriert</p>}
            </div>

            <div style={{
              background: 'white',
              padding: '15px',
              borderRadius: '10px',
              marginBottom: '15px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
            }}>
              <h3 style={{ color: '#667eea', marginBottom: '10px', fontSize: '1.1em' }}>Gesamtpunktzahl</h3>
              <div style={{ fontSize: '3em', fontWeight: 'bold', color: '#764ba2', textAlign: 'center' }}>
                {totalScore}
              </div>
            </div>

            <div style={{
              background: 'white',
              padding: '15px',
              borderRadius: '10px',
              marginBottom: '15px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
            }}>
              <h3 style={{ color: '#667eea', marginBottom: '10px', fontSize: '1.1em' }}>Treffer pro Ring</h3>
              <div style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: '8px',
                fontSize: '0.9em'
              }}>
                {[9, 8, 7, 6, 5, 4, 3, 2, 1, 0].map(ring => (
                  <div key={ring} style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '5px',
                    background: '#f0f0f0',
                    borderRadius: '5px'
                  }}>
                    <span>Ring {ring}:</span>
                    <strong>{ringHits[ring]}</strong>
                  </div>
                ))}
              </div>
            </div>

            <div style={{
              background: 'white',
              padding: '15px',
              borderRadius: '10px',
              marginBottom: '15px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
            }}>
              <h3 style={{ color: '#667eea', marginBottom: '10px', fontSize: '1.1em' }}>Letzte Schüsse</h3>
              <div style={{ fontSize: '0.9em', maxHeight: '150px', overflowY: 'auto' }}>
                {shots.slice(-10).reverse().map((shot, idx) => (
                  <div key={shot.timestamp} style={{
                    padding: '5px',
                    borderBottom: '1px solid #ddd'
                  }}>
                    Schuss {shots.length - idx}: <strong>{shot.score} Punkte</strong>
                  </div>
                ))}
                {shots.length === 0 && <p>Keine Treffer</p>}
              </div>
            </div>

            <div style={{
              background: 'white',
              padding: '15px',
              borderRadius: '10px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
            }}>
              <h3 style={{ color: '#667eea', marginBottom: '10px', fontSize: '1.1em' }}>Durchschnitt</h3>
              <div style={{ fontSize: '2em', fontWeight: 'bold', textAlign: 'center', color: '#667eea' }}>
                {avgScore}
              </div>
            </div>
          </div>

          {/* Target */}
          <div>
            <div style={{
              position: 'relative',
              width: '600px',
              height: '600px',
              margin: '0 auto',
              background: 'white',
              borderRadius: '15px',
              boxShadow: '0 4px 15px rgba(0,0,0,0.2)',
              cursor: calibrationMode ? 'crosshair' : (systemActive ? 'pointer' : 'default')
            }}>
              <svg 
                viewBox="0 0 1000 1000" 
                style={{ width: '100%', height: '100%' }}
                onClick={handleTargetClick}
              >
                {/* Zielscheiben-Ringe */}
                <circle cx="500" cy="500" r="500" fill="white" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="444" fill="#f0f0f0" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="388" fill="white" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="333" fill="#f0f0f0" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="277" fill="white" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="222" fill="#f0f0f0" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="166" fill="#666" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="111" fill="#f0f0f0" stroke="#333" strokeWidth="2"/>
                <circle cx="500" cy="500" r="55" fill="white" stroke="#333" strokeWidth="2"/>
                
                {/* Ring-Zahlen */}
                <text x="500" y="520" fontSize="40" textAnchor="middle" fill="#333">9</text>
                <text x="500" y="410" fontSize="30" textAnchor="middle" fill="#333">8</text>
                <text x="500" y="320" fontSize="30" textAnchor="middle" fill="#666">7</text>
                <text x="500" y="230" fontSize="30" textAnchor="middle" fill="#333">6</text>
                <text x="500" y="140" fontSize="30" textAnchor="middle" fill="#666">5</text>
                <text x="500" y="50" fontSize="30" textAnchor="middle" fill="#333">4</text>

                {/* Kalibrierungspunkte */}
                <circle cx="50" cy="50" r="15" fill="black" />
                <text x="50" y="30" fontSize="24" textAnchor="middle" fill="black" fontWeight="bold">1</text>
                
                <circle cx="950" cy="50" r="15" fill="black" />
                <text x="950" y="30" fontSize="24" textAnchor="middle" fill="black" fontWeight="bold">2</text>
                
                <circle cx="950" cy="950" r="15" fill="black" />
                <text x="950" y="980" fontSize="24" textAnchor="middle" fill="black" fontWeight="bold">3</text>
                
                <circle cx="50" cy="950" r="15" fill="black" />
                <text x="50" y="980" fontSize="24" textAnchor="middle" fill="black" fontWeight="bold">4</text>

                {/* Einschusslöcher */}
                {shots.map((shot, idx) => (
                  <g key={idx}>
                    <circle 
                      cx={shot.x} 
                      cy={shot.y} 
                      r="8" 
                      fill="#e74c3c" 
                      stroke="#000" 
                      strokeWidth="1" 
                      opacity="0.8"
                    />
                    <text 
                      x={shot.x} 
                      y={shot.y - 12} 
                      fontSize="12" 
                      textAnchor="middle" 
                      fill="#000" 
                      fontWeight="bold"
                    >
                      {shot.score}
                    </text>
                  </g>
                ))}

                {/* Kalibrierungs-Feedback */}
                {calibrationMode && calibrationStep < 4 && (
                  <text 
                    x="500" 
                    y="500" 
                    fontSize="30" 
                    textAnchor="middle" 
                    fill="#f39c12" 
                    fontWeight="bold"
                  >
                    Punkt {calibrationStep + 1} klicken
                  </text>
                )}
              </svg>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div style={{
          display: 'flex',
          gap: '15px',
          justifyContent: 'center',
          flexWrap: 'wrap',
          marginBottom: '30px'
        }}>
          <button 
            onClick={startSystem}
            disabled={systemActive || !isCalibrated}
            style={{
              padding: '12px 30px',
              border: 'none',
              borderRadius: '25px',
              fontSize: '1em',
              fontWeight: '600',
              cursor: systemActive || !isCalibrated ? 'not-allowed' : 'pointer',
              background: systemActive || !isCalibrated ? '#ccc' : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              opacity: systemActive || !isCalibrated ? 0.5 : 1
            }}
          >
            ▶ Start
          </button>
          
          <button 
            onClick={stopSystem}
            disabled={!systemActive}
            style={{
              padding: '12px 30px',
              border: 'none',
              borderRadius: '25px',
              fontSize: '1em',
              fontWeight: '600',
              cursor: !systemActive ? 'not-allowed' : 'pointer',
              background: !systemActive ? '#ccc' : '#e74c3c',
              color: 'white',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              opacity: !systemActive ? 0.5 : 1
            }}
          >
            ⏹ Stop
          </button>
          
          <button 
            onClick={resetShots}
            style={{
              padding: '12px 30px',
              border: 'none',
              borderRadius: '25px',
              fontSize: '1em',
              fontWeight: '600',
              cursor: 'pointer',
              background: '#e74c3c',
              color: 'white',
              textTransform: 'uppercase',
              letterSpacing: '1px'
            }}
          >
            🔄 Reset Treffer
          </button>
          
          <button 
            onClick={startCalibration}
            style={{
              padding: '12px 30px',
              border: 'none',
              borderRadius: '25px',
              fontSize: '1em',
              fontWeight: '600',
              cursor: 'pointer',
              background: '#f39c12',
              color: 'white',
              textTransform: 'uppercase',
              letterSpacing: '1px'
            }}
          >
            📐 Kalibrierung
          </button>

          <button 
            onClick={simulateShot}
            disabled={!systemActive}
            style={{
              padding: '12px 30px',
              border: 'none',
              borderRadius: '25px',
              fontSize: '1em',
              fontWeight: '600',
              cursor: !systemActive ? 'not-allowed' : 'pointer',
              background: !systemActive ? '#ccc' : '#2ecc71',
              color: 'white',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              opacity: !systemActive ? 0.5 : 1
            }}
          >
            🎲 Demo-Schuss
          </button>
        </div>

        {/* Settings */}
        <div style={{
          background: '#f8f9fa',
          padding: '20px',
          borderRadius: '15px'
        }}>
          <h3 style={{ marginBottom: '20px' }}>⚙️ Kamera-Einstellungen</h3>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '20px'
          }}>
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600', color: '#555' }}>
                Helligkeit: <span style={{ color: '#667eea', fontWeight: 'bold' }}>{settings.brightness}</span>
              </label>
              <input 
                type="range" 
                min="-2" 
                max="2" 
                value={settings.brightness}
                onChange={e => setSettings({...settings, brightness: parseInt(e.target.value)})}
                style={{ width: '100%' }}
              />
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600', color: '#555' }}>
                Kontrast: <span style={{ color: '#667eea', fontWeight: 'bold' }}>{settings.contrast}</span>
              </label>
              <input 
                type="range" 
                min="-2" 
                max="2" 
                value={settings.contrast}
                onChange={e => setSettings({...settings, contrast: parseInt(e.target.value)})}
                style={{ width: '100%' }}
              />
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600', color: '#555' }}>
                Sättigung: <span style={{ color: '#667eea', fontWeight: 'bold' }}>{settings.saturation}</span>
              </label>
              <input 
                type="range" 
                min="-2" 
                max="2" 
                value={settings.saturation}
                onChange={e => setSettings({...settings, saturation: parseInt(e.target.value)})}
                style={{ width: '100%' }}
              />
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600', color: '#555' }}>
                Laser-Schwellwert: <span style={{ color: '#667eea', fontWeight: 'bold' }}>{settings.threshold}</span>
              </label>
              <input 
                type="range" 
                min="100" 
                max="255" 
                value={settings.threshold}
                onChange={e => setSettings({...settings, threshold: parseInt(e.target.value)})}
                style={{ width: '100%' }}
              />
            </div>
          </div>
          
          <button 
            onClick={() => alert('Einstellungen gespeichert (Demo-Modus)')}
            style={{
              padding: '12px 30px',
              border: 'none',
              borderRadius: '25px',
              fontSize: '1em',
              fontWeight: '600',
              cursor: 'pointer',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              marginTop: '15px'
            }}
          >
            💾 Einstellungen speichern
          </button>
        </div>
      </div>
    </div>
  );
}
