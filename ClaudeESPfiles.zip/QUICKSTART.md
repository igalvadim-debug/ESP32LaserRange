# 🚀 Quick Start Guide - ESP32 Laser Target Tracker

## Schnellstart in 5 Schritten

### 1️⃣ WiFi einstellen
Öffne die `.ino` Datei und ändere:
```cpp
const char* ssid = "DEIN_WIFI_NAME";
const char* password = "DEIN_WIFI_PASSWORT";
```

### 2️⃣ Auf ESP32-CAM hochladen
- **Arduino IDE:** Board = "AI Thinker ESP32-CAM", Upload Speed = 115200
- **Wichtig:** GPIO0 mit GND verbinden beim Upload!
- Nach Upload: GPIO0 trennen und Reset drücken

### 3️⃣ IP-Adresse finden
- Serial Monitor öffnen (115200 baud)
- IP-Adresse notieren (z.B. `192.168.1.100`)

### 4️⃣ Browser öffnen
- Gehe zu: `http://DEINE_IP_ADRESSE`
- WebUI sollte erscheinen

### 5️⃣ Kalibrieren & Loslegen
1. Klicke **"📐 Kalibrierung"**
2. Klicke auf die 4 schwarzen Punkte (1→2→3→4)
3. **System startet automatisch** nach Kalibrierung
4. Schieße mit dem Laser!

**Hinweis:** Nach dem ersten Kalibrieren startet das System bei jedem Neustart automatisch.

## ⚡ Häufigste Probleme

| Problem | Lösung |
|---------|--------|
| Upload funktioniert nicht | GPIO0 mit GND verbinden |
| Keine WiFi-Verbindung | Nur 2.4GHz WiFi verwenden |
| Laser wird nicht erkannt | Schwellwert senken (150-180) |
| Zu viele Fehlalarme | Schwellwert erhöhen (220-240) |
| System zählt nicht | Erst kalibrieren! |

## 📁 Projektstruktur

```
ESP32_LaserTarget_Tracker/
├── Arduino/              ← Arduino IDE Projekt
│   └── ESP32_LaserTarget_Tracker.ino
├── VSCode/              ← PlatformIO Projekt
│   ├── platformio.ini
│   └── src/main.cpp
├── docs/                ← Vollständige Dokumentation
│   └── README.md
├── demo/                ← Interaktive WebUI Demo
│   └── LaserTargetDemo.jsx
├── print_target.png     ← Zielscheibe zum Ausdrucken
└── QUICKSTART.md        ← Diese Datei
```

## 🎯 Was du brauchst

**Hardware:**
- ESP32-CAM Modul
- FTDI Programmer (zum Upload)
- Laser Pointer
- Zielscheibe (drucke `print_target.png`)

**Software:**
- Arduino IDE ODER VS Code + PlatformIO
- ArduinoJson Library (Version 6.x)

## 💡 Tipps für beste Ergebnisse

1. **Beleuchtung:** Raum nicht zu hell, keine direkten Reflexionen
2. **Laser:** Rote Laser funktionieren besser als grüne
3. **Zielscheibe:** Flach an Wand, alle 4 Punkte sichtbar
4. **Kamera-Position:** Zielscheibe vollständig im Bild
5. **Schwellwert:** Starte mit 200, passe an deine Umgebung an

## 🔗 Mehr Infos

Siehe `docs/README.md` für:
- Detaillierte Installation
- Troubleshooting
- API-Dokumentation
- Erweiterte Konfiguration

---

**Viel Spaß! 🎯**
